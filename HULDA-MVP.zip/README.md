# HULƊA MVP

Wannan shi ne frontend MVP na HULƊA: multilingual local service discovery.

## Yadda za ka kunna shi
1. Cire ZIP.
2. Buɗe `index.html` a browser.
3. Ko ka ɗora dukkan files ɗin zuwa GitHub Pages / Cloudflare Pages.

## Abin da ke aiki yanzu
- Hausa / English switch
- Search
- Service categories
- Provider cards
- Profile modal
- Login UI demo
- Provider registration UI demo
- Responsive mobile design

## Mataki na gaba
- Firebase Authentication
- Firestore database
- Real provider profiles
- WhatsApp/contact links
- Location & distance
- AI natural-language search
- Reviews
- Provider verification
- Payments/commission
- Admin dashboard

Wannan MVP ba ya sarrafa real payments kuma ba ya adana bayanan users.
