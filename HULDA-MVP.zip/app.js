const providers = [
  {name:"Aminu Phone Care",cat:"Mai gyaran waya",icon:"📱",place:"Bichi, Kano",rating:4.9,verified:true,desc:"Gyaran Android, iPhone, software da accessories."},
  {name:"A T L Graphics",cat:"Graphic Designer",icon:"🎨",place:"Kano",rating:4.8,verified:true,desc:"Logo, flyer, social media design da branding."},
  {name:"Malam Sani Maths",cat:"Malami",icon:"📚",place:"Online • Nigeria",rating:4.9,verified:true,desc:"Koyar da Mathematics da Calculus ga Level 100."},
  {name:"Zainab Tailoring",cat:"Mai dinki",icon:"🧵",place:"Bichi, Kano",rating:4.7,verified:false,desc:"Dinki na mata, gyaran kaya da custom orders."},
  {name:"Bichi Tech Fix",cat:"Computer",icon:"💻",place:"Bichi, Kano",rating:4.6,verified:true,desc:"Computer repair, Windows, networking da setup."},
  {name:"Umar Electric",cat:"Electrician",icon:"⚡",place:"Kano",rating:4.8,verified:false,desc:"Wiring, inverter, generator da electrical repairs."}
];

const translations = {
  ha:{services:"Ayyuka",how:"Yadda yake aiki",login:"Shiga",tagline:"Ka faɗi abin da kake nema",
    heroTitle:"HULƊA ta nemo maka wanda ya dace.",heroText:"Nemo mai sana'a, malami, technician, designer ko wani service — cikin Hausa ko English.",
    search:"Nemo",phone:"Gyaran waya",teacher:"Malami",tailor:"Dinki",discover:"GANO",popular:"Ayyukan da mutane ke nema",near:"Kusa da ni",
    empty:"Ba mu sami abin da ya dace ba. Gwada wata kalma.",simple:"Sauƙi ne kawai.",step1Title:"Faɗi abin da kake nema",step1:"Rubuta ko zaɓi category.",
    step2Title:"Duba masu dacewa",step2:"Kwatanta rating, nesa da bayanin service.",step3Title:"Haɗu da wanda ya dace",step3:"Tuntuɓi provider kai tsaye.",
    joinTitle:"Kana da sana'a? A sa mutane su same ka.",joinText:"Ƙirƙiri profile kyauta. Daga baya za mu ƙara verification, premium profile da biyan kuɗi.",join:"Ƙirƙiri profile",footer:"Haɗa mutane da dama, cikin sauƙi."},
  en:{services:"Services",how:"How it works",login:"Log in",tagline:"Tell us what you need",
    heroTitle:"HULƊA finds the right person for you.",heroText:"Find a professional, teacher, technician, designer or service — in Hausa or English.",
    search:"Search",phone:"Phone repair",teacher:"Teacher",tailor:"Tailoring",discover:"DISCOVER",popular:"Popular services",near:"Near me",
    empty:"No matching service found. Try another search.",simple:"It is that simple.",step1Title:"Tell us what you need",step1:"Type it or choose a category.",
    step2Title:"Compare your matches",step2:"Compare ratings, distance and service details.",step3Title:"Connect with the right person",step3:"Contact the provider directly.",
    joinTitle:"Have a skill? Let people find you.",joinText:"Create a free profile. Later we'll add verification, premium profiles and payments.",join:"Create profile",footer:"Connecting people, simply."}
};
let lang="ha";

function render(list=providers){
  const box=document.getElementById("results"), empty=document.getElementById("empty");
  box.innerHTML="";
  empty.classList.toggle("hidden",list.length>0);
  list.forEach((p,i)=>{
    const card=document.createElement("article"); card.className="card";
    card.innerHTML=`<div class="card-top"><div class="avatar">${p.icon}</div>${p.verified?'<span class="verified">✓ VERIFIED</span>':''}</div>
      <h3>${p.name}</h3><div class="meta">${p.cat} · ${p.place}</div>
      <p class="meta">${p.desc}</p><div class="rating">★ <b>${p.rating}</b> ·  ${Math.floor(p.rating*23)+4} reviews</div>
      <button data-index="${i}">Duba profile</button>`;
    box.appendChild(card);
  });
  box.querySelectorAll("button").forEach(btn=>btn.onclick=()=>showProvider(list[+btn.dataset.index]));
}
function showProvider(p){
  openModal(`<div class="avatar">${p.icon}</div><h2>${p.name}</h2><p class="meta">${p.cat} · ${p.place}</p><p>${p.desc}</p><p>⭐ <b>${p.rating}</b> · ${p.verified?"Verified provider":"Provider profile"}</p><button class="primary" id="contactBtn">Tuntuɓi ${p.name}</button>`);
  document.getElementById("contactBtn").onclick=()=>openModal(`<h2>Tuntuɓar ${p.name}</h2><p class="meta">A wannan MVP, wannan zai iya zama WhatsApp/chat. Za mu haɗa shi da backend daga baya.</p><button class="primary" onclick="closeModal()">To, na fahimta</button>`);
}
function openModal(html){document.getElementById("modalContent").innerHTML=html;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function search(){
  const q=document.getElementById("searchInput").value.toLowerCase().trim();
  if(!q){render();return}
  const words=q.split(/\s+/);
  const list=providers.filter(p=>(p.name+" "+p.cat+" "+p.place+" "+p.desc).toLowerCase().split(" ").some(w=>words.some(x=>w.includes(x))));
  render(list);
  document.getElementById("services").scrollIntoView({behavior:"smooth"});
}
function applyLang(){
  document.documentElement.lang=lang;
  document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=translations[lang][el.dataset.i18n]||el.textContent);
  document.getElementById("langBtn").textContent=lang==="ha"?"EN":"HA";
  const input=document.getElementById("searchInput");
  input.placeholder=lang==="ha"?input.dataset.placeholderHa:input.dataset.placeholderEn;
}
document.getElementById("searchForm").onsubmit=e=>{e.preventDefault();search()};
document.querySelectorAll(".chip").forEach(c=>c.onclick=()=>{document.getElementById("searchInput").value=c.dataset.query;search()});
document.getElementById("langBtn").onclick=()=>{lang=lang==="ha"?"en":"ha";applyLang()};
document.getElementById("nearBtn").onclick=()=>openModal(`<h2>Kusa da ni</h2><p>Za mu nemi izinin location a version na gaba domin nuna providers mafi kusa da kai.</p><button class="primary" onclick="closeModal()">To</button>`);
document.getElementById("loginBtn").onclick=()=>openModal(`<h2>Shiga HULƊA</h2><p class="meta">MVP ne yanzu. Za mu haɗa Firebase/Auth a mataki na gaba.</p><input placeholder="Email"><input type="password" placeholder="Password"><button class="primary">Shiga</button>`);
document.getElementById("joinBtn").onclick=()=>openModal(`<h2>Ƙirƙiri profile</h2><p class="meta">Mataki na farko: saka sunanka da sana'arka.</p><input placeholder="Sunanka"><input placeholder="Sana'a / service"><input placeholder="Wuri"><button class="primary">Ci gaba</button>`);
document.getElementById("closeModal").onclick=closeModal;
document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
render();applyLang();
